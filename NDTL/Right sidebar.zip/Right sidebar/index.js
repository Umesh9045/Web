document.querySelector("sidebar-menu .toggle-btn").addEventListener("click", function () {
   
    document.querySelector("sidebar-menu").classList.toggle("active");
  });
  
  